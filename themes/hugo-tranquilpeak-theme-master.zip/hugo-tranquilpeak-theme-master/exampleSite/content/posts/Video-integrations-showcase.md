---
title: Video integrations showcase
date: 2014-08-09
thumbnailImagePosition: left
thumbnailImage: //d1u9biwaxjngwg.cloudfront.net/video-integration-showcase/peak-140.jpg
categories:
- tranquilpeak
- features
tags:
- videos integration
- youtube
- vimeo
- dailymotion
---

Youtube and Vimeo videos are easily integrated thanks to tags plugins. Of course, you can add video other platforms like dailymotion.
<!--more-->

**Youtube**

{{< youtube xL45JMI8IFg >}}

**Vimeo**

{{< vimeo 17877190 >}}
